const CACHE = 'veilborn-v2';
const RUNTIME = 'veilborn-runtime-v1';
const SHELL = ['./index_9.html', './manifest.json', './icon-192.png', './icon-512.png'];
// Static CDN hosts safe to cache for offline/quick replay (game engine + auth SDK files only —
// never Firebase's live database/auth API traffic, which must always stay network-only).
const RUNTIME_HOSTS = ['cdn.jsdelivr.net', 'www.gstatic.com'];

self.addEventListener('install', e => {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).catch(() => {}));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE && k !== RUNTIME).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);

  // Same-origin app shell: cache-first, refresh in background (stale-while-revalidate).
  if (url.origin === location.origin) {
    e.respondWith(
      caches.match(e.request).then(cached => {
        const network = fetch(e.request)
          .then(res => {
            if (res && res.ok) caches.open(CACHE).then(c => c.put(e.request, res.clone()));
            return res;
          })
          .catch(() => cached);
        return cached || network;
      })
    );
    return;
  }

  // Static engine/SDK modules from trusted CDNs: cache temporarily so the game boots
  // instantly on repeat visits and can still load with a flaky or offline connection.
  if (RUNTIME_HOSTS.includes(url.hostname)) {
    e.respondWith(
      caches.open(RUNTIME).then(cache =>
        cache.match(e.request).then(cached => {
          const network = fetch(e.request)
            .then(res => {
              if (res && res.ok) cache.put(e.request, res.clone());
              return res;
            })
            .catch(() => cached);
          return cached || network;
        })
      )
    );
    return;
  }

  // Everything else (Firebase Realtime Database, Auth, Analytics, remote images):
  // network-only — never cached, always live.
});
